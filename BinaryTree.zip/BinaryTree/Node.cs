﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryTree.BinaryTree
{
    internal class Node
    {
        public Node? Left;
        public Node? Right;
        public int Value;

        public Node(int value)
        {
            Value = value;
            Left  = null;
            Right = null;
        }
    }
}
