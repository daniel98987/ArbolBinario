﻿using System;

namespace BinaryTree.BinaryTree
{
    internal class BinaryTreeHandler
    {
        public Node Root { get; private set; }

        public BinaryTreeHandler(int value)
        {
            Root = new Node(value);
        }

        public void Insert(int value)
        {
            InsertNodeOrValue(Root, value);
        }

        private void InsertNodeOrValue(Node root, int value)
        {
            if (value == root.Value)
                return;

            if (value < root.Value)
            {
                if (root.Left == null)
                    root.Left = new Node(value);
                else
                    InsertNodeOrValue(root.Left, value);
            }
            else
            {
                if (root.Right == null)
                    root.Right = new Node(value);
                else
                    InsertNodeOrValue(root.Right, value);
            }
        }

        public bool Exists(Node? root, int value)
        {
            if (root == null) return false;
            if (root.Value == value) return true;
            return value < root.Value
                ? Exists(root.Left, value)
                : Exists(root.Right, value);
        }


        public Node? FindAncestor(Node? root, int n1, int n2)
        {
            if (root == null) return null;

            if (!Exists(Root, n1) || !Exists(Root, n2))
                return null;

            if (n1 < root.Value && n2 < root.Value)
                return FindAncestor(root.Left, n1, n2);

            if (n1 > root.Value && n2 > root.Value)
                return FindAncestor(root.Right, n1, n2);

            return root; 
        }
        public void InOrder(Node? root)
        {
            if (root == null) return;
            InOrder(root.Left);
            Console.Write(root.Value + " ");
            InOrder(root.Right);
        }
    }
}
